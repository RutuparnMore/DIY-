const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_FILE = path.join(__dirname, 'projects.json');

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Helper: read projects from JSON file
function readProjects() {
  if (!fs.existsSync(DATA_FILE)) {
    return [];
  }
  const raw = fs.readFileSync(DATA_FILE, 'utf8') || '[]';
  return JSON.parse(raw);
}

// Helper: write projects to JSON file
function writeProjects(projects) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(projects, null, 2), 'utf8');
}

// GET all projects
app.get('/api/projects', (req, res) => {
  try {
    const projects = readProjects();
    res.json(projects);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to read projects.' });
  }
});

// GET single project by id
app.get('/api/projects/:id', (req, res) => {
  try {
    const projects = readProjects();
    const project = projects.find(p => String(p.id) === String(req.params.id));
    if (!project) {
      return res.status(404).json({ error: 'Project not found.' });
    }
    res.json(project);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to read project.' });
  }
});

// POST create a new project
// Body: { title, shortDescription, youtubeUrl, materials: [], scienceBehind, tags: [], difficulty, ageRange, thumbnailUrl }
app.post('/api/projects', (req, res) => {
  try {
    const {
      title,
      shortDescription,
      youtubeUrl,
      materials = [],
      scienceBehind = '',
      tags = [],
      difficulty = 'Easy',
      ageRange = '7-12',
      thumbnailUrl = ''
    } = req.body || {};

    if (!title || !youtubeUrl) {
      return res.status(400).json({ error: 'title and youtubeUrl are required.' });
    }

    const projects = readProjects();
    const newId = projects.length ? Math.max(...projects.map(p => Number(p.id))) + 1 : 1;

    const newProject = {
      id: newId,
      title,
      shortDescription: shortDescription || '',
      youtubeUrl,
      materials,
      scienceBehind,
      tags,
      difficulty,
      ageRange,
      thumbnailUrl
    };

    projects.push(newProject);
    writeProjects(projects);

    res.status(201).json(newProject);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create project.' });
  }
});

// Fallback to index.html for SPA-style routing (optional)
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`DIY Kids site server running on http://localhost:${PORT}`);
});

