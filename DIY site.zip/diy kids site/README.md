# DIY Lab for Kids

A simple DIY projects website for kids where each project shows an embedded YouTube video (no redirect to YouTube), a list of materials, and an explanation of the science behind it. Projects are displayed in a card grid similar to an e‑commerce catalog.

## How it works

- **Backend**: Node.js + Express.
  - Serves a JSON API at `/api/projects`.
  - Reads and writes project data from `projects.json`.
- **Frontend**: Static HTML/CSS/JS in `public/`.
  - Calls `/api/projects` to list all projects.
  - When you select a project, it embeds the YouTube video on the page using an `<iframe>` instead of redirecting to YouTube.
  - Under the video, it shows **Materials Needed** and **Science Behind It**.

## Getting started

1. Install Node.js (v18+ is recommended).
2. In a terminal, go to this folder:

   ```bash
   cd "d:\diy kids site"
   ```

3. Install dependencies:

   ```bash
   npm install
   ```

4. Start the server:

   ```bash
   npm start
   ```

5. Open the site in your browser:

   ```text
   http://localhost:3000
   ```

## Adding or editing projects

There are **two** ways to manage projects:

### 1. Edit `projects.json` by hand

Open `projects.json` and add a new object to the array:

```json
{
  "id": 3,
  "title": "Paper Bridge Challenge",
  "shortDescription": "Build the strongest bridge using only paper.",
  "youtubeUrl": "https://www.youtube.com/watch?v=YOUR_VIDEO_ID",
  "materials": [
    "A4 printer paper",
    "Coins or small weights",
    "Books to act as supports"
  ],
  "scienceBehind": "Explain the science here...",
  "tags": ["engineering", "design"],
  "difficulty": "Medium",
  "ageRange": "8-14",
  "thumbnailUrl": ""
}
```

- **Important**: Make sure every `id` is unique and numeric.
- Put the **normal YouTube link** in `youtubeUrl` (for example, `https://www.youtube.com/watch?v=VIDEO_ID`).  
  The frontend automatically converts this to an embedded video so it plays inside your site.

### 2. Use the API to create a project

Send a `POST` request to:

```text
POST http://localhost:3000/api/projects
Content-Type: application/json
```

Body example:

```json
{
  "title": "Balloon Rocket Experiment",
  "shortDescription": "Learn about Newton's third law with a balloon rocket.",
  "youtubeUrl": "https://www.youtube.com/watch?v=VIDEO_ID",
  "materials": [
    "Balloon",
    "String",
    "Straw",
    "Tape"
  ],
  "scienceBehind": "Explain that the escaping air pushes backward, so the balloon moves forward (action–reaction).",
  "tags": ["physics", "rockets"],
  "difficulty": "Easy",
  "ageRange": "7-12",
  "thumbnailUrl": ""
}
```

On success, the new project is saved into `projects.json` and will show up in the grid.

## Mapping to your Figma design

- You can adjust the layout and colors in `public/styles.css` to match your Figma mockup.
- Update text, logo, and structure in `public/index.html` as needed.
- The logic that embeds the YouTube video and shows materials + science explanation is in `public/app.js` (`showProjectDetail` function).

